package com.chmod.kyc.api

import com.chmod.kyc.domain.enums.VerificationResultCode
import kotlin.uuid.ExperimentalUuidApi
import kotlin.uuid.Uuid

@OptIn(ExperimentalUuidApi::class)
public sealed interface VerificationResult {
    public val transactionId: Uuid?
    public val code: VerificationResultCode
    public val message: String

    public data class Completed(
        override val transactionId: Uuid?,
        override val code: VerificationResultCode = VerificationResultCode.VERIFICATION_COMPLETED,
        override val message: String = "Verification completed successfully"
    ) : VerificationResult

    public data class Cancelled(
        override val transactionId: Uuid?,
        override val code: VerificationResultCode = VerificationResultCode.VERIFICATION_CANCELLED,
        override val message: String = "User cancelled the verification"
    ) : VerificationResult

    public data class Failed(
        override val transactionId: Uuid?,
        override val code: VerificationResultCode,
        override val message: String
    ) : VerificationResult
}
