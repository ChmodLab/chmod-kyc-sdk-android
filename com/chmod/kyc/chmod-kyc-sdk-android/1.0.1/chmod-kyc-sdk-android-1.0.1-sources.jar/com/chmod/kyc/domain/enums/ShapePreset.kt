package com.chmod.kyc.domain.enums

import kotlinx.serialization.Serializable

@Serializable
public enum class ShapePreset { NONE, EXTRA_SMALL, SMALL, MEDIUM, LARGE, EXTRA_LARGE, FULL }
