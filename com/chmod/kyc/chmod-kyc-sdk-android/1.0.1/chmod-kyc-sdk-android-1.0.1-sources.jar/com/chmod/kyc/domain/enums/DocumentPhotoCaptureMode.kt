package com.chmod.kyc.domain.enums

import kotlinx.serialization.Serializable

@Serializable
public enum class DocumentPhotoCaptureMode { AUTO, MANUAL }
