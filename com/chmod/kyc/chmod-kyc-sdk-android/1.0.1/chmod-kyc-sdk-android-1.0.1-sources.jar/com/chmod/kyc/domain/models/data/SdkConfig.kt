package com.chmod.kyc.domain.models.data

import androidx.compose.ui.text.font.FontFamily
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient
import com.chmod.kyc.domain.enums.DocumentPhotoCaptureMode
import com.chmod.kyc.domain.enums.DocumentTypeDetectionMode
import com.chmod.kyc.domain.enums.Language
import com.chmod.kyc.domain.enums.LocationPermissionMode
import com.chmod.kyc.domain.enums.ShapePreset
import com.chmod.kyc.domain.enums.ThemeMode

@Serializable
public data class SdkConfig(
    val appearance: Appearance = Appearance(),
    val locale: Locale = Locale(),
    val documentCapture: DocumentCapture = DocumentCapture(),
    val showResultScreen: Boolean = SdkConfigDefaults.showResultScreen,
    val showErrorDetail: Boolean = SdkConfigDefaults.showErrorDetail,
    val locationPermission: LocationPermissionMode = SdkConfigDefaults.locationPermission
) {
    @Serializable
    public data class Appearance(
        val theme: ThemeMode = SdkConfigDefaults.theme,
        val light: ThemeColors = SdkConfigDefaults.lightColors,
        val dark: ThemeColors = SdkConfigDefaults.darkColors,
        val typography: Typography = Typography(),
        val shapes: Shapes = Shapes()
    )

        @Serializable

        public data class ThemeColors(
            val primary: String? = null,
            val onPrimary: String? = null,
            val background: String? = null,
            val surface: String? = null,
            val secondary: String? = null,
            val onSecondary: String? = null,
            val tertiary: String? = null,
            val onTertiary: String? = null,
            val onBackground: String? = null,
            val onSurface: String? = null,
            val onSurfaceVariant: String? = null,
            val surfaceVariant: String? = null,
            val error: String? = null,
            val onError: String? = null,
            val outline: String? = null,
            val resultSuccessBackground: String? = null,
            val resultSuccessIcon: String? = null,
            val resultErrorBackground: String? = null,
            val resultErrorIcon: String? = null
        ) {
            public companion object {
                public fun defaultLight(): ThemeColors = SdkConfigDefaults.lightColors
                public fun defaultDark(): ThemeColors = SdkConfigDefaults.darkColors
            }
        }

    @Serializable

    public data class Typography(
        @Transient val fontFamily: FontFamily = FontFamily.Default,
        val bodySize: Int = SdkConfigDefaults.bodySize,
        val titleSize: Int = SdkConfigDefaults.titleSize,
        val labelSize: Int = SdkConfigDefaults.labelSize
    )

    @Serializable

    public data class Shapes(
        val preset: ShapePreset = SdkConfigDefaults.shapePreset
    )

    @Serializable

    public data class Locale(
        val defaultLanguage: Language = SdkConfigDefaults.defaultLanguage,
        val fallbackLanguage: Language = SdkConfigDefaults.fallbackLanguage,
        val allowLanguageSelection: Boolean = SdkConfigDefaults.allowLanguageSelection,
        val texts: List<Translation> = emptyList()
    )

    @Serializable

    public data class Translation(
        val language: Language,
        val key: String,
        val value: String
    )

    @Serializable

    public data class DocumentCapture(
        val documentTypeDetectionMode: DocumentTypeDetectionMode = SdkConfigDefaults.documentTypeDetectionMode,
        val documentPhotoCaptureMode: DocumentPhotoCaptureMode = SdkConfigDefaults.documentPhotoCaptureMode,
        val showPhotoPreview: Boolean = SdkConfigDefaults.showPhotoPreview,
        val showDocumentTrackingOutline: Boolean = SdkConfigDefaults.showDocumentTrackingOutline,
        val maxPhotoRetakeOnFailed: Int = SdkConfigDefaults.maxPhotoRetakeOnFailed,
        val trustUserDocumentCapture: Boolean = SdkConfigDefaults.trustUserDocumentCapture
    )
}