package com.chmod.kyc.domain.enums

import kotlinx.serialization.Serializable

@Serializable
public enum class ThemeMode { SYSTEM, LIGHT, DARK }
