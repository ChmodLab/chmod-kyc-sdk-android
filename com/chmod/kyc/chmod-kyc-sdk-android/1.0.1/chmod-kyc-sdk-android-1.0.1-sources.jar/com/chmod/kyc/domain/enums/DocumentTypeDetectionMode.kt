package com.chmod.kyc.domain.enums

import kotlinx.serialization.Serializable

@Serializable
public enum class DocumentTypeDetectionMode {
    AUTO,
    USER_SELECT,
    USER_SELECT_STRICT,
    AUTO_AND_HIDE_DOCUMENT_OPTIONS;

    internal val isUserSelected: Boolean
        get() = this == USER_SELECT || this == USER_SELECT_STRICT

    internal val enforcesSelection: Boolean
        get() = this == USER_SELECT_STRICT
}
