package com.chmod.kyc.domain.enums

public enum class Language {
    DEVICE, en, es, pt, fr, it, de, ru;

    public companion object {
        public val supported: List<Language> = entries.filter { it != DEVICE }

        public fun fromCode(code: String): Language? =
            entries.firstOrNull { it.name.equals(code, ignoreCase = true) }
    }
}
